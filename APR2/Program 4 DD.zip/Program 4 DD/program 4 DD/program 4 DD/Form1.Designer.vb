﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chklube = New System.Windows.Forms.CheckBox()
        Me.chkoil = New System.Windows.Forms.CheckBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chktrans = New System.Windows.Forms.CheckBox()
        Me.chkradiator = New System.Windows.Forms.CheckBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.chktire = New System.Windows.Forms.CheckBox()
        Me.chkreplace = New System.Windows.Forms.CheckBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.chkinspec = New System.Windows.Forms.CheckBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtlabor = New System.Windows.Forms.TextBox()
        Me.txtparts = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lbltotal = New System.Windows.Forms.Label()
        Me.lbltax = New System.Windows.Forms.Label()
        Me.lblparts = New System.Windows.Forms.Label()
        Me.lblservice = New System.Windows.Forms.Label()
        Me.y = New System.Windows.Forms.Label()
        Me.btncal = New System.Windows.Forms.Button()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.btnexit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chklube)
        Me.GroupBox1.Controls.Add(Me.chkoil)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Location = New System.Drawing.Point(28, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GroupBox1.Size = New System.Drawing.Size(321, 128)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Oil and Lube"
        '
        'chklube
        '
        Me.chklube.AutoSize = True
        Me.chklube.Location = New System.Drawing.Point(18, 78)
        Me.chklube.Name = "chklube"
        Me.chklube.Size = New System.Drawing.Size(89, 21)
        Me.chklube.TabIndex = 1
        Me.chklube.Text = "Lube Job"
        Me.chklube.UseVisualStyleBackColor = True
        '
        'chkoil
        '
        Me.chkoil.AutoSize = True
        Me.chkoil.Location = New System.Drawing.Point(18, 33)
        Me.chkoil.Name = "chkoil"
        Me.chkoil.Size = New System.Drawing.Size(100, 21)
        Me.chkoil.TabIndex = 0
        Me.chkoil.Text = "Oil Change"
        Me.chkoil.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(171, 77)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(62, 17)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "($18.00)"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(171, 34)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(62, 17)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "($26.00)"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chktrans)
        Me.GroupBox2.Controls.Add(Me.chkradiator)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Location = New System.Drawing.Point(383, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GroupBox2.Size = New System.Drawing.Size(332, 128)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Flushes"
        '
        'chktrans
        '
        Me.chktrans.AutoSize = True
        Me.chktrans.Location = New System.Drawing.Point(26, 77)
        Me.chktrans.Name = "chktrans"
        Me.chktrans.Size = New System.Drawing.Size(152, 21)
        Me.chktrans.TabIndex = 1
        Me.chktrans.Text = "Transmission Flush"
        Me.chktrans.UseVisualStyleBackColor = True
        '
        'chkradiator
        '
        Me.chkradiator.AutoSize = True
        Me.chkradiator.Location = New System.Drawing.Point(26, 32)
        Me.chkradiator.Name = "chkradiator"
        Me.chkradiator.Size = New System.Drawing.Size(122, 21)
        Me.chkradiator.TabIndex = 0
        Me.chkradiator.Text = "Radiator Flush"
        Me.chkradiator.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(197, 77)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(62, 17)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "($80.00)"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(197, 32)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(62, 17)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "($30.00)"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.chktire)
        Me.GroupBox3.Controls.Add(Me.chkreplace)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.chkinspec)
        Me.GroupBox3.Location = New System.Drawing.Point(28, 162)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GroupBox3.Size = New System.Drawing.Size(321, 160)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Misc"
        '
        'chktire
        '
        Me.chktire.AutoSize = True
        Me.chktire.Location = New System.Drawing.Point(18, 116)
        Me.chktire.Name = "chktire"
        Me.chktire.Size = New System.Drawing.Size(108, 21)
        Me.chktire.TabIndex = 2
        Me.chktire.Text = "Tire Rotaion"
        Me.chktire.UseVisualStyleBackColor = True
        '
        'chkreplace
        '
        Me.chkreplace.AutoSize = True
        Me.chkreplace.Location = New System.Drawing.Point(18, 74)
        Me.chkreplace.Name = "chkreplace"
        Me.chkreplace.Size = New System.Drawing.Size(132, 21)
        Me.chkreplace.TabIndex = 1
        Me.chkreplace.Text = "Replace Muffiler"
        Me.chkreplace.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(171, 116)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(62, 17)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "($20.00)"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(171, 74)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(70, 17)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "($100.00)"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(171, 32)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(62, 17)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "($15.00)"
        '
        'chkinspec
        '
        Me.chkinspec.AutoSize = True
        Me.chkinspec.Location = New System.Drawing.Point(18, 32)
        Me.chkinspec.Name = "chkinspec"
        Me.chkinspec.Size = New System.Drawing.Size(94, 21)
        Me.chkinspec.TabIndex = 0
        Me.chkinspec.Text = "Inspection"
        Me.chkinspec.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label3)
        Me.GroupBox4.Controls.Add(Me.Label2)
        Me.GroupBox4.Controls.Add(Me.Label1)
        Me.GroupBox4.Controls.Add(Me.txtlabor)
        Me.GroupBox4.Controls.Add(Me.txtparts)
        Me.GroupBox4.Location = New System.Drawing.Point(383, 162)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GroupBox4.Size = New System.Drawing.Size(321, 160)
        Me.GroupBox4.TabIndex = 2
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Parts and Labor"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(181, 103)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(120, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "($20.00 per hour)"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(17, 103)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Labor"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(17, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 17)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Parts"
        '
        'txtlabor
        '
        Me.txtlabor.Location = New System.Drawing.Point(76, 100)
        Me.txtlabor.Name = "txtlabor"
        Me.txtlabor.Size = New System.Drawing.Size(86, 22)
        Me.txtlabor.TabIndex = 1
        '
        'txtparts
        '
        Me.txtparts.Location = New System.Drawing.Point(76, 44)
        Me.txtparts.Name = "txtparts"
        Me.txtparts.Size = New System.Drawing.Size(86, 22)
        Me.txtparts.TabIndex = 0
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label6)
        Me.GroupBox5.Controls.Add(Me.Label5)
        Me.GroupBox5.Controls.Add(Me.Label4)
        Me.GroupBox5.Controls.Add(Me.lbltotal)
        Me.GroupBox5.Controls.Add(Me.lbltax)
        Me.GroupBox5.Controls.Add(Me.lblparts)
        Me.GroupBox5.Controls.Add(Me.lblservice)
        Me.GroupBox5.Controls.Add(Me.y)
        Me.GroupBox5.Location = New System.Drawing.Point(154, 342)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GroupBox5.Size = New System.Drawing.Size(417, 171)
        Me.GroupBox5.TabIndex = 3
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Summary"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(66, 142)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(75, 17)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Total Fees"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(66, 100)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(98, 17)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Tax (on Parts)"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(66, 59)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 17)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Parts"
        '
        'lbltotal
        '
        Me.lbltotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbltotal.Location = New System.Drawing.Point(249, 141)
        Me.lbltotal.Name = "lbltotal"
        Me.lbltotal.Size = New System.Drawing.Size(131, 17)
        Me.lbltotal.TabIndex = 0
        '
        'lbltax
        '
        Me.lbltax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbltax.Location = New System.Drawing.Point(249, 99)
        Me.lbltax.Name = "lbltax"
        Me.lbltax.Size = New System.Drawing.Size(131, 17)
        Me.lbltax.TabIndex = 0
        '
        'lblparts
        '
        Me.lblparts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblparts.Location = New System.Drawing.Point(249, 58)
        Me.lblparts.Name = "lblparts"
        Me.lblparts.Size = New System.Drawing.Size(131, 17)
        Me.lblparts.TabIndex = 0
        '
        'lblservice
        '
        Me.lblservice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblservice.Location = New System.Drawing.Point(249, 18)
        Me.lblservice.Name = "lblservice"
        Me.lblservice.Size = New System.Drawing.Size(131, 17)
        Me.lblservice.TabIndex = 0
        '
        'y
        '
        Me.y.AutoSize = True
        Me.y.Location = New System.Drawing.Point(66, 18)
        Me.y.Name = "y"
        Me.y.Size = New System.Drawing.Size(131, 17)
        Me.y.TabIndex = 0
        Me.y.Text = "Services and Labor"
        '
        'btncal
        '
        Me.btncal.Location = New System.Drawing.Point(46, 538)
        Me.btncal.Name = "btncal"
        Me.btncal.Size = New System.Drawing.Size(136, 33)
        Me.btncal.TabIndex = 4
        Me.btncal.Text = "calculate total"
        Me.btncal.UseVisualStyleBackColor = True
        '
        'btnclear
        '
        Me.btnclear.Location = New System.Drawing.Point(302, 538)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(139, 33)
        Me.btnclear.TabIndex = 4
        Me.btnclear.Text = "Clear"
        Me.btnclear.UseVisualStyleBackColor = True
        '
        'btnexit
        '
        Me.btnexit.Location = New System.Drawing.Point(557, 538)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(127, 33)
        Me.btnexit.TabIndex = 4
        Me.btnexit.Text = "Exit"
        Me.btnexit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(738, 595)
        Me.Controls.Add(Me.btnexit)
        Me.Controls.Add(Me.btnclear)
        Me.Controls.Add(Me.btncal)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Text = "Joe's Automotive"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents chklube As System.Windows.Forms.CheckBox
    Friend WithEvents chkoil As System.Windows.Forms.CheckBox
    Friend WithEvents chktrans As System.Windows.Forms.CheckBox
    Friend WithEvents chkradiator As System.Windows.Forms.CheckBox
    Friend WithEvents chktire As System.Windows.Forms.CheckBox
    Friend WithEvents chkreplace As System.Windows.Forms.CheckBox
    Friend WithEvents chkinspec As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtlabor As System.Windows.Forms.TextBox
    Friend WithEvents txtparts As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents y As System.Windows.Forms.Label
    Friend WithEvents btncal As System.Windows.Forms.Button
    Friend WithEvents btnclear As System.Windows.Forms.Button
    Friend WithEvents btnexit As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents lbltotal As System.Windows.Forms.Label
    Friend WithEvents lbltax As System.Windows.Forms.Label
    Friend WithEvents lblparts As System.Windows.Forms.Label
    Friend WithEvents lblservice As System.Windows.Forms.Label

End Class
