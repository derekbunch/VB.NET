﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Radio_Buttons
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Me.btnExit = New System.Windows.Forms.Button()
		Me.btnOk = New System.Windows.Forms.Button()
		Me.GroupBox1 = New System.Windows.Forms.GroupBox()
		Me.radSoftDrink = New System.Windows.Forms.RadioButton()
		Me.radTea = New System.Windows.Forms.RadioButton()
		Me.radCoffee = New System.Windows.Forms.RadioButton()
		Me.GroupBox2 = New System.Windows.Forms.GroupBox()
		Me.RadioButton1 = New System.Windows.Forms.RadioButton()
		Me.RadioButton2 = New System.Windows.Forms.RadioButton()
		Me.RadioButton3 = New System.Windows.Forms.RadioButton()
		Me.GroupBox1.SuspendLayout()
		Me.GroupBox2.SuspendLayout()
		Me.SuspendLayout()
		'
		'btnExit
		'
		Me.btnExit.Location = New System.Drawing.Point(198, 181)
		Me.btnExit.Margin = New System.Windows.Forms.Padding(4)
		Me.btnExit.Name = "btnExit"
		Me.btnExit.Size = New System.Drawing.Size(71, 28)
		Me.btnExit.TabIndex = 7
		Me.btnExit.Text = "Cancel"
		Me.btnExit.UseVisualStyleBackColor = True
		'
		'btnOk
		'
		Me.btnOk.Location = New System.Drawing.Point(94, 181)
		Me.btnOk.Margin = New System.Windows.Forms.Padding(4)
		Me.btnOk.Name = "btnOk"
		Me.btnOk.Size = New System.Drawing.Size(65, 28)
		Me.btnOk.TabIndex = 6
		Me.btnOk.Text = "&OK"
		Me.btnOk.UseVisualStyleBackColor = True
		'
		'GroupBox1
		'
		Me.GroupBox1.Controls.Add(Me.radSoftDrink)
		Me.GroupBox1.Controls.Add(Me.radTea)
		Me.GroupBox1.Controls.Add(Me.radCoffee)
		Me.GroupBox1.Location = New System.Drawing.Point(34, 33)
		Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
		Me.GroupBox1.Name = "GroupBox1"
		Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
		Me.GroupBox1.Size = New System.Drawing.Size(140, 128)
		Me.GroupBox1.TabIndex = 8
		Me.GroupBox1.TabStop = False
		Me.GroupBox1.Text = "Side Orders"
		'
		'radSoftDrink
		'
		Me.radSoftDrink.AutoSize = True
		Me.radSoftDrink.Location = New System.Drawing.Point(25, 84)
		Me.radSoftDrink.Margin = New System.Windows.Forms.Padding(4)
		Me.radSoftDrink.Name = "radSoftDrink"
		Me.radSoftDrink.Size = New System.Drawing.Size(86, 20)
		Me.radSoftDrink.TabIndex = 2
		Me.radSoftDrink.TabStop = True
		Me.radSoftDrink.Text = "Cole Slaw"
		Me.radSoftDrink.UseVisualStyleBackColor = True
		'
		'radTea
		'
		Me.radTea.AutoSize = True
		Me.radTea.Location = New System.Drawing.Point(25, 55)
		Me.radTea.Margin = New System.Windows.Forms.Padding(4)
		Me.radTea.Name = "radTea"
		Me.radTea.Size = New System.Drawing.Size(60, 20)
		Me.radTea.TabIndex = 1
		Me.radTea.TabStop = True
		Me.radTea.Text = "Chips"
		Me.radTea.UseVisualStyleBackColor = True
		'
		'radCoffee
		'
		Me.radCoffee.AutoSize = True
		Me.radCoffee.Location = New System.Drawing.Point(25, 26)
		Me.radCoffee.Margin = New System.Windows.Forms.Padding(4)
		Me.radCoffee.Name = "radCoffee"
		Me.radCoffee.Size = New System.Drawing.Size(100, 20)
		Me.radCoffee.TabIndex = 0
		Me.radCoffee.TabStop = True
		Me.radCoffee.Text = "French Fries"
		Me.radCoffee.UseVisualStyleBackColor = True
		'
		'GroupBox2
		'
		Me.GroupBox2.Controls.Add(Me.RadioButton1)
		Me.GroupBox2.Controls.Add(Me.RadioButton2)
		Me.GroupBox2.Controls.Add(Me.RadioButton3)
		Me.GroupBox2.Location = New System.Drawing.Point(198, 33)
		Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4)
		Me.GroupBox2.Name = "GroupBox2"
		Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4)
		Me.GroupBox2.Size = New System.Drawing.Size(140, 128)
		Me.GroupBox2.TabIndex = 9
		Me.GroupBox2.TabStop = False
		Me.GroupBox2.Text = "Drinks"
		'
		'RadioButton1
		'
		Me.RadioButton1.AutoSize = True
		Me.RadioButton1.Location = New System.Drawing.Point(25, 84)
		Me.RadioButton1.Margin = New System.Windows.Forms.Padding(4)
		Me.RadioButton1.Name = "RadioButton1"
		Me.RadioButton1.Size = New System.Drawing.Size(83, 20)
		Me.RadioButton1.TabIndex = 2
		Me.RadioButton1.TabStop = True
		Me.RadioButton1.Text = "Soft Drink"
		Me.RadioButton1.UseVisualStyleBackColor = True
		'
		'RadioButton2
		'
		Me.RadioButton2.AutoSize = True
		Me.RadioButton2.Location = New System.Drawing.Point(25, 55)
		Me.RadioButton2.Margin = New System.Windows.Forms.Padding(4)
		Me.RadioButton2.Name = "RadioButton2"
		Me.RadioButton2.Size = New System.Drawing.Size(51, 20)
		Me.RadioButton2.TabIndex = 1
		Me.RadioButton2.TabStop = True
		Me.RadioButton2.Text = "Tea"
		Me.RadioButton2.UseVisualStyleBackColor = True
		'
		'RadioButton3
		'
		Me.RadioButton3.AutoSize = True
		Me.RadioButton3.Location = New System.Drawing.Point(25, 26)
		Me.RadioButton3.Margin = New System.Windows.Forms.Padding(4)
		Me.RadioButton3.Name = "RadioButton3"
		Me.RadioButton3.Size = New System.Drawing.Size(65, 20)
		Me.RadioButton3.TabIndex = 0
		Me.RadioButton3.TabStop = True
		Me.RadioButton3.Text = "Coffee"
		Me.RadioButton3.UseVisualStyleBackColor = True
		'
		'Radio_Buttons
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(365, 230)
		Me.Controls.Add(Me.GroupBox2)
		Me.Controls.Add(Me.GroupBox1)
		Me.Controls.Add(Me.btnExit)
		Me.Controls.Add(Me.btnOk)
		Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.Name = "Radio_Buttons"
		Me.Text = "Radio Buttons"
		Me.GroupBox1.ResumeLayout(False)
		Me.GroupBox1.PerformLayout()
		Me.GroupBox2.ResumeLayout(False)
		Me.GroupBox2.PerformLayout()
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents btnExit As System.Windows.Forms.Button
	Friend WithEvents btnOk As System.Windows.Forms.Button
	Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
	Friend WithEvents radSoftDrink As System.Windows.Forms.RadioButton
	Friend WithEvents radTea As System.Windows.Forms.RadioButton
	Friend WithEvents radCoffee As System.Windows.Forms.RadioButton
	Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
	Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
	Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
	Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
End Class
