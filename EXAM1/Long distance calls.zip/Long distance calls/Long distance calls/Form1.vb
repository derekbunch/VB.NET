﻿Public Class Form1

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub BtnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        ' Define variables
        Dim intMinutes As Integer               'Number of minutes
        Dim decTotal As Decimal                 'Total charge

        'Define constants
        Const decDaytime As Decimal = 0.07      'Daytime rate/minute
        Const decEvening As Decimal = 0.12      'Evening rate/minute
        Const decOff As Decimal = 0.05          'Off-Peak rate/minute

        'Check for errors
        If Integer.TryParse(TextBox1.Text, intMinutes) = False Then
            lblStatus.Text = "Number of minutes must be a numeric value."
            Return
        End If

        intMinutes = CInt(TextBox1.Text)

        If intMinutes < 1 Then
            lblStatus.Text = "Number of minutes must be greater than zero."
            Return
        End If

        'Calculate charges
        If radDaytime.Checked = True Then
            decTotal = decDaytime * intMinutes
        ElseIf radEvening.Checked = True Then
            decTotal = decEvening * intMinutes
        ElseIf radOff.Checked = True Then
            decTotal = decOff * intMinutes
        End If

        'Display the total charges
        lblTotal.Text = decTotal.ToString("c")
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clear the form
        radDaytime.Checked = False
        radEvening.Checked = False
        radOff.Checked = False
        TextBox1.Text = ""
        lblTotal.Text = ""
        lblStatus.Text = ""
    End Sub
End Class
